﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && !Class1.hash.ContainsKey(textBox2.Text) && !Class1.hash.ContainsValue(textBox1.Text))
            {
                Class1.hash.Add(textBox2.Text, textBox1.Text);
                listBox1.Items.Add(Class1.hash[textBox2.Text].ToString() + " " + textBox2.Text);

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex >= 0)
                listBox1.Items.Remove(listBox1.SelectedItem);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox3.Text != "")
                foreach (var item in Class1.hash.Keys)
                {
                    if (Convert.ToInt32(item) == Convert.ToInt32(textBox3.Text))
                    {
                        MessageBox.Show(Class1.hash[item].ToString() + " " + item);
                    }
                }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox4.Text != "")
                foreach (var item in Class1.hash.Keys)
                {
                    if (Class1.hash[item].ToString() == textBox4.Text)
                    {
                        MessageBox.Show(Class1.hash[item] + " " + item);
                    }
                }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
